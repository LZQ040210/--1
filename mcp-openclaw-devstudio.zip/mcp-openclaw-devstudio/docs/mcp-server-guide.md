# MCP Server Builder 开发指南

本指南介绍如何使用 MCP Server Builder 快速创建 MCP Server。

## 快速开始

### 1. 选择模板

从模板市场选择合适的起点：

- **数据库类**: MySQL, PostgreSQL, Redis
- **API 集成**: GitHub, Notion, Stripe
- **文件系统**: Local File System
- **自定义**: 从头开始

### 2. 配置 Server

#### 基础配置
- Server 名称和版本
- 描述信息

#### 传输协议
- **STDIO**: 本地进程通信（推荐）
- **HTTP**: 跨网络通信
- **WebSocket**: 双向实时通信

#### 认证设置
- None: 无需认证
- API Key: 简单认证
- OAuth2: 标准 OAuth2 流程
- JWT: Token 认证

#### 资源定义
定义 MCP Resources:
```typescript
{
  uri: "mysql://tables/{table_name}",
  name: "Table Data",
  description: "Access table data",
  mimeType: "application/json"
}
```

#### 工具定义
定义 MCP Tools:
```typescript
{
  name: "query_table",
  description: "Query data from a table",
  inputSchema: {
    type: "object",
    properties: {
      table_name: { type: "string" },
      limit: { type: "number" }
    },
    required: ["table_name"]
  },
  handler: {
    type: "sql"
  }
}
```

### 3. 生成代码

选择目标语言和选项：
- **语言**: TypeScript / Python
- **包含测试**: 生成单元测试代码
- **包含 Dockerfile**: 生成容器化配置

### 4. 运行 Server

```bash
# 安装依赖
npm install

# 开发模式
npm run dev

# 生产构建
npm run build
npm start
```

## 最佳实践

### 安全
- 使用环境变量存储敏感信息
- 实施最小权限原则
- 添加请求速率限制

### 性能
- 使用连接池管理数据库连接
- 实现缓存策略
- 监控响应时间

### 可维护性
- 编写详细的代码注释
- 保持配置和代码分离
- 实现完整的错误处理

## 示例：创建 GitHub MCP Server

1. 选择 "GitHub API" 模板
2. 配置 GITHUB_TOKEN 环境变量
3. 添加需要的工具（get_repository, list_issues）
4. 生成 TypeScript 代码
5. 运行并测试

## 相关资源

- [MCP 协议规范](https://modelcontextprotocol.io)
- [OpenClaw 文档](https://openclaw.ai)
- [官方 SDK](https://github.com/modelcontextprotocol/typescript-sdk)
