import React, { useState } from 'react';
import { TemplateSelector } from '@mcp-devstudio/mcp-server-builder/components/TemplateSelector';
import { ServerConfigForm } from '@mcp-devstudio/mcp-server-builder/components/ServerConfigForm';
import { TemplateMetadata, MCPServerConfig, generateMCPServerCode } from '@mcp-devstudio/mcp-server-builder';

function App() {
  const [currentStep, setCurrentStep] = useState<
    | 'select-template'
    | 'configure'
    | 'generate'
  >('select-template');

  const [selectedTemplate, setSelectedTemplate] = useState<TemplateMetadata | null>(null);
  const [config, setConfig] = useState<MCPServerConfig | null>(null);
  const [generatedFiles, setGeneratedFiles] = useState<Map<string, string> | null>(null);

  const handleTemplateSelect = (template: TemplateMetadata) => {
    setSelectedTemplate(template);
    setConfig(template.config);
    setCurrentStep('configure');
  };

  const handleConfigSave = (savedConfig: MCPServerConfig) => {
    setConfig(savedConfig);
  };

  const handleGenerate = async (generateConfig: MCPServerConfig) => {
    const files = await generateMCPServerCode(generateConfig, {
      language: 'typescript',
      outputDir: './output',
      includeTests: true,
      includeDockerfile: true,
    });
    setGeneratedFiles(files);
    setCurrentStep('generate');
  };

  const handleBack = () => {
    if (currentStep === 'configure') {
      setCurrentStep('select-template');
      setSelectedTemplate(null);
    } else if (currentStep === 'generate') {
      setCurrentStep('configure');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航 */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold text-gray-900">
                MCP & OpenClaw DevStudio
              </h1>
              <span className="text-sm text-gray-500">|</span>
              <nav className="flex gap-2">
                {[
                  { step: 'select-template', label: '选择模板' },
                  { step: 'configure', label: '配置 Server', disabled: !selectedTemplate },
                  { step: 'generate', label: '生成代码', disabled: !config },
                ].map((item, index) => (
                  <span
                    key={item.step}
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      currentStep === item.step
                        ? 'bg-blue-600 text-white'
                        : item.disabled
                        ? 'bg-gray-100 text-gray-400'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {index + 1}. {item.label}
                  </span>
                ))}
              </nav>
            </div>
            <div className="text-sm text-gray-500">
              让 MCP Server 开发更简单
            </div>
          </div>
        </div>
      </header>

      {/* 主内容区 */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentStep === 'select-template' && (
          <div>
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-2">
                选择 MCP Server 模板
              </h2>
              <p className="text-gray-600">
                从预置模板中选择，或从零开始创建自定义 Server
              </p>
            </div>
            <TemplateSelector onTemplateSelect={handleTemplateSelect} />
          </div>
        )}

        {currentStep === 'configure' && config && (
          <div>
            <div className="mb-6">
              <button
                onClick={handleBack}
                className="text-blue-600 hover:text-blue-800 text-sm mb-2"
              >
                ← 返回模板选择
              </button>
              <h2 className="text-xl font-semibold text-gray-900">
                配置 {selectedTemplate?.name || 'MCP Server'}
              </h2>
              <p className="text-gray-600">
                自定义 Server 配置，生成适合您需求的代码
              </p>
            </div>
            <ServerConfigForm
              initialConfig={config}
              onSave={handleConfigSave}
              onGenerate={handleGenerate}
            />
          </div>
        )}

        {currentStep === 'generate' && generatedFiles && (
          <div>
            <div className="mb-6">
              <button
                onClick={handleBack}
                className="text-blue-600 hover:text-blue-800 text-sm mb-2"
              >
                ← 返回配置
              </button>
              <h2 className="text-xl font-semibold text-gray-900">
                代码生成完成
              </h2>
              <p className="text-gray-600">
                共生成 {generatedFiles.size} 个文件
              </p>
            </div>

            <div className="space-y-4">
              {Array.from(generatedFiles.entries()).map(([filename, content]) => (
                <div key={filename} className="bg-white rounded-lg shadow border border-gray-200">
                  <div className="border-b border-gray-200 px-4 py-2 flex justify-between items-center bg-gray-50">
                    <span className="font-mono text-sm font-medium text-gray-700">
                      {filename}
                    </span>
                    <button
                      onClick={() => navigator.clipboard.writeText(content)}
                      className="text-sm text-blue-600 hover:text-blue-800"
                    >
                      复制
                    </button>
                  </div>
                  <pre className="p-4 overflow-x-auto text-sm bg-gray-900 text-gray-100 max-h-96">
                    <code>{content}</code>
                  </pre>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h3 className="font-medium text-blue-900 mb-2">下一步</h3>
              <ol className="list-decimal list-inside space-y-1 text-sm text-blue-800">
                <li>下载生成的代码文件</li>
                <li>安装依赖：npm install</li>
                <li>配置环境变量（如 API Key）</li>
                <li>运行开发服务器：npm run dev</li>
              </ol>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
