import { z } from 'zod';

// MCP Server 配置 Schema
export const MCPServerConfigSchema = z.object({
  name: z.string().min(1).max(64),
  version: z.string().regex(/^\d+\.\d+\.\d+$/),
  description: z.string().max(500),
  
  // 传输协议配置
  transport: z.enum(['stdio', 'http', 'websocket']),
  port: z.number().optional(),
  
  // 认证配置
  authentication: z.object({
    type: z.enum(['none', 'api_key', 'oauth2', 'jwt']),
    apiKey: z.string().optional(),
    oauth2Config: z.object({
      authUrl: z.string().url().optional(),
      tokenUrl: z.string().url().optional(),
      clientId: z.string().optional(),
      clientSecret: z.string().optional(),
      scopes: z.array(z.string()).optional(),
    }).optional(),
  }).optional(),
  
  // 资源定义
  resources: z.array(z.object({
    uri: z.string(),
    name: z.string(),
    description: z.string(),
    mimeType: z.string(),
    template: z.object({
      type: z.enum(['uri_template', 'static']),
      pattern: z.string().optional(),
    }).optional(),
  })).optional(),
  
  // 工具定义
  tools: z.array(z.object({
    name: z.string(),
    description: z.string(),
    inputSchema: z.object({
      type: z.literal('object'),
      properties: z.record(z.any()),
      required: z.array(z.string()).optional(),
    }),
    handler: z.object({
      type: z.enum(['function', 'http', 'sql']),
      endpoint: z.string().optional(),
      method: z.enum(['GET', 'POST', 'PUT', 'DELETE']).optional(),
      sqlQuery: z.string().optional(),
    }),
  })).optional(),
  
  // 提示词模板
  prompts: z.array(z.object({
    name: z.string(),
    description: z.string(),
    arguments: z.array(z.object({
      name: z.string(),
      description: z.string(),
      required: z.boolean(),
    })).optional(),
    template: z.string(),
  })).optional(),
});

export type MCPServerConfig = z.infer<typeof MCPServerConfigSchema>;

// 代码生成选项
export interface CodeGenOptions {
  language: 'typescript' | 'python';
  outputDir: string;
  includeTests: boolean;
  includeDockerfile: boolean;
}

// 模板元数据
export interface TemplateMetadata {
  id: string;
  name: string;
  description: string;
  category: 'database' | 'api' | 'file' | 'custom';
  icon: string;
  config: MCPServerConfig;
}
