import { TemplateMetadata } from './types';

export const MCP_TEMPLATES: TemplateMetadata[] = [
  {
    id: 'mysql-server',
    name: 'MySQL Database',
    description: 'Expose MySQL database tables as MCP resources and tools',
    category: 'database',
    icon: 'database',
    config: {
      name: 'mysql-mcp-server',
      version: '1.0.0',
      description: 'MCP Server for MySQL database access',
      transport: 'stdio',
      authentication: {
        type: 'api_key',
        apiKey: '${MYSQL_API_KEY}',
      },
      resources: [
        {
          uri: 'mysql://tables/{table_name}',
          name: 'Table Data',
          description: 'Access table data from the database',
          mimeType: 'application/json',
          template: {
            type: 'uri_template',
            pattern: 'mysql://tables/{table_name}',
          },
        },
      ],
      tools: [
        {
          name: 'query_table',
          description: 'Query data from a specific table',
          inputSchema: {
            type: 'object',
            properties: {
              table_name: { type: 'string', description: 'Name of the table to query' },
              limit: { type: 'number', description: 'Maximum number of rows to return', default: 100 },
              where: { type: 'string', description: 'WHERE clause (optional)' },
            },
            required: ['table_name'],
          },
          handler: {
            type: 'sql',
            sqlQuery: 'SELECT * FROM {table_name} {where} LIMIT {limit}',
          },
        },
      ],
    },
  },
  
  {
    id: 'github-server',
    name: 'GitHub API',
    description: 'Interact with GitHub repositories, issues, and pull requests',
    category: 'api',
    icon: 'github',
    config: {
      name: 'github-mcp-server',
      version: '1.0.0',
      description: 'MCP Server for GitHub API integration',
      transport: 'http',
      port: 3001,
      authentication: {
        type: 'api_key',
        apiKey: '${GITHUB_TOKEN}',
      },
      tools: [
        {
          name: 'get_repository',
          description: 'Get repository information',
          inputSchema: {
            type: 'object',
            properties: {
              owner: { type: 'string', description: 'Repository owner' },
              repo: { type: 'string', description: 'Repository name' },
            },
            required: ['owner', 'repo'],
          },
          handler: {
            type: 'http',
            endpoint: 'https://api.github.com/repos/{owner}/{repo}',
            method: 'GET',
          },
        },
        {
          name: 'list_issues',
          description: 'List issues in a repository',
          inputSchema: {
            type: 'object',
            properties: {
              owner: { type: 'string', description: 'Repository owner' },
              repo: { type: 'string', description: 'Repository name' },
              state: { type: 'string', description: 'Issue state: open, closed, all', enum: ['open', 'closed', 'all'] },
            },
            required: ['owner', 'repo'],
          },
          handler: {
            type: 'http',
            endpoint: 'https://api.github.com/repos/{owner}/{repo}/issues',
            method: 'GET',
          },
        },
      ],
    },
  },
  
  {
    id: 'postgresql-server',
    name: 'PostgreSQL Database',
    description: 'Expose PostgreSQL database with advanced query capabilities',
    category: 'database',
    icon: 'database',
    config: {
      name: 'postgresql-mcp-server',
      version: '1.0.0',
      description: 'MCP Server for PostgreSQL database access',
      transport: 'stdio',
      authentication: {
        type: 'api_key',
        apiKey: '{{POSTGRES_API_KEY}}',
      },
      resources: [
        {
          uri: 'postgres://schemas',
          name: 'Database Schemas',
          description: 'List all schemas in the database',
          mimeType: 'application/json',
        },
        {
          uri: 'postgres://tables/{schema}/{table}',
          name: 'Table Metadata',
          description: 'Get table schema and statistics',
          mimeType: 'application/json',
        },
      ],
      tools: [
        {
          name: 'execute_query',
          description: 'Execute a custom SQL query',
          inputSchema: {
            type: 'object',
            properties: {
              query: { type: 'string', description: 'SQL query to execute' },
              parameters: { type: 'array', description: 'Query parameters', items: { type: 'string' } },
            },
            required: ['query'],
          },
          handler: {
            type: 'sql',
            sqlQuery: '{query}',
          },
        },
      ],
    },
  },
  
  {
    id: 'notion-server',
    name: 'Notion API',
    description: 'Access and modify Notion pages and databases',
    category: 'api',
    icon: 'document',
    config: {
      name: 'notion-mcp-server',
      version: '1.0.0',
      description: 'MCP Server for Notion integration',
      transport: 'http',
      port: 3002,
      authentication: {
        type: 'api_key',
        apiKey: '${NOTION_API_KEY}',
      },
      tools: [
        {
          name: 'get_page',
          description: 'Get a Notion page by ID',
          inputSchema: {
            type: 'object',
            properties: {
              page_id: { type: 'string', description: 'Notion page ID' },
            },
            required: ['page_id'],
          },
          handler: {
            type: 'http',
            endpoint: 'https://api.notion.com/v1/pages/{page_id}',
            method: 'GET',
          },
        },
        {
          name: 'query_database',
          description: 'Query a Notion database',
          inputSchema: {
            type: 'object',
            properties: {
              database_id: { type: 'string', description: 'Notion database ID' },
              filter: { type: 'object', description: 'Query filter' },
            },
            required: ['database_id'],
          },
          handler: {
            type: 'http',
            endpoint: 'https://api.notion.com/v1/databases/{database_id}/query',
            method: 'POST',
          },
        },
      ],
    },
  },
  
  {
    id: 'file-server',
    name: 'Local File System',
    description: 'Read and write files on the local file system',
    category: 'file',
    icon: 'folder',
    config: {
      name: 'file-mcp-server',
      version: '1.0.0',
      description: 'MCP Server for local file system access',
      transport: 'stdio',
      authentication: {
        type: 'none',
      },
      resources: [
        {
          uri: 'file://{path}',
          name: 'File Content',
          description: 'Access file content by path',
          mimeType: 'text/plain',
          template: {
            type: 'uri_template',
            pattern: 'file://{path}',
          },
        },
      ],
      tools: [
        {
          name: 'read_file',
          description: 'Read content of a file',
          inputSchema: {
            type: 'object',
            properties: {
              path: { type: 'string', description: 'File path to read' },
              encoding: { type: 'string', description: 'File encoding', default: 'utf-8' },
            },
            required: ['path'],
          },
          handler: {
            type: 'function',
          },
        },
        {
          name: 'write_file',
          description: 'Write content to a file',
          inputSchema: {
            type: 'object',
            properties: {
              path: { type: 'string', description: 'File path to write' },
              content: { type: 'string', description: 'Content to write' },
            },
            required: ['path', 'content'],
          },
          handler: {
            type: 'function',
          },
        },
      ],
    },
  },
];

export function getTemplateById(id: string): TemplateMetadata | undefined {
  return MCP_TEMPLATES.find(t => t.id === id);
}

export function getTemplatesByCategory(category: string): TemplateMetadata[] {
  return MCP_TEMPLATES.filter(t => t.category === category);
}
