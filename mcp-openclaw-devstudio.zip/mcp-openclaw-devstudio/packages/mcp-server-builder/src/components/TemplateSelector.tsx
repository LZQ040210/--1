'use client';

import React, { useState } from 'react';
import { MCPServerConfig, TemplateMetadata } from '@mcp-devstudio/mcp-server-builder';
import { MCP_TEMPLATES, getTemplateById } from '@mcp-devstudio/mcp-server-builder';

interface TemplateCardProps {
  template: TemplateMetadata;
  onSelect: (template: TemplateMetadata) => void;
}

function TemplateCard({ template, onSelect }: TemplateCardProps) {
  const categoryIcons: Record<string, string> = {
    database: '🗄️',
    api: '🔌',
    file: '📁',
    custom: '⚙️',
  };

  return (
    <div
      className="border border-gray-200 rounded-lg p-4 hover:border-blue-500 hover:shadow-md transition-all cursor-pointer bg-white"
      onClick={() => onSelect(template)}
    >
      <div className="flex items-center gap-3 mb-3">
        <span className="text-3xl">{categoryIcons[template.category] || '⚙️'}</span>
        <div>
          <h3 className="font-semibold text-gray-900">{template.name}</h3>
          <p className="text-sm text-gray-500">{template.id}</p>
        </div>
      </div>
      <p className="text-sm text-gray-600 mb-3">{template.description}</p>
      <div className="flex items-center justify-between">
        <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600">
          v{template.config.version}
        </span>
        <span className="text-xs text-blue-600 font-medium">选择 →</span>
      </div>
    </div>
  );
}

interface TemplateSelectorProps {
  onTemplateSelect: (template: TemplateMetadata) => void;
}

export function TemplateSelector({ onTemplateSelect }: TemplateSelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'all', name: '全部', count: MCP_TEMPLATES.length },
    { id: 'database', name: '数据库', count: MCP_TEMPLATES.filter(t => t.category === 'database').length },
    { id: 'api', name: 'API 集成', count: MCP_TEMPLATES.filter(t => t.category === 'api').length },
    { id: 'file', name: '文件系统', count: MCP_TEMPLATES.filter(t => t.category === 'file').length },
    { id: 'custom', name: '自定义', count: MCP_TEMPLATES.filter(t => t.category === 'custom').length },
  ];

  const filteredTemplates = MCP_TEMPLATES.filter(template => {
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* 搜索栏 */}
      <div className="space-y-4">
        <input
          type="text"
          placeholder="搜索模板..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        
        {/* 分类筛选 */}
        <div className="flex gap-2 flex-wrap">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedCategory === category.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {category.name} ({category.count})
            </button>
          ))}
        </div>
      </div>

      {/* 模板网格 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTemplates.map(template => (
          <TemplateCard
            key={template.id}
            template={template}
            onSelect={onTemplateSelect}
          />
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">未找到匹配的模板</p>
          <p className="text-sm text-gray-400 mt-2">尝试其他关键词或分类</p>
        </div>
      )}
    </div>
  );
}
