'use client';

import React, { useState } from 'react';
import { MCPServerConfig } from '@mcp-devstudio/mcp-server-builder';

interface ServerConfigFormProps {
  initialConfig?: MCPServerConfig;
  onSave: (config: MCPServerConfig) => void;
  onGenerate: (config: MCPServerConfig) => void;
}

export function ServerConfigForm({ initialConfig, onSave, onGenerate }: ServerConfigFormProps) {
  const [config, setConfig] = useState<MCPServerConfig>(
    initialConfig || {
      name: '',
      version: '1.0.0',
      description: '',
      transport: 'stdio',
      port: 3000,
      authentication: {
        type: 'none',
      },
      resources: [],
      tools: [],
      prompts: [],
    }
  );

  const [activeTab, setActiveTab] = useState<'basic' | 'transport' | 'auth' | 'resources' | 'tools'>('basic');

  const handleBasicSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(config);
  };

  const addResource = () => {
    setConfig(prev => ({
      ...prev,
      resources: [
        ...(prev.resources || []),
        {
          uri: '',
          name: '',
          description: '',
          mimeType: 'application/json',
        },
      ],
    }));
  };

  const addTool = () => {
    setConfig(prev => ({
      ...prev,
      tools: [
        ...(prev.tools || []),
        {
          name: '',
          description: '',
          inputSchema: {
            type: 'object',
            properties: {},
            required: [],
          },
          handler: {
            type: 'function',
          },
        },
      ],
    }));
  };

  return (
    <div className="bg-white rounded-lg shadow">
      {/* 标签页导航 */}
      <div className="border-b border-gray-200">
        <nav className="flex gap-4 px-4">
          {[
            { id: 'basic', label: '基础配置' },
            { id: 'transport', label: '传输协议' },
            { id: 'auth', label: '认证设置' },
            { id: 'resources', label: '资源定义' },
            { id: 'tools', label: '工具定义' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`py-3 px-2 border-b-2 font-medium text-sm transition-all ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* 表单内容 */}
      <form onSubmit={handleBasicSave} className="p-6 space-y-4">
        {activeTab === 'basic' && (
          <>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Server 名称 *
              </label>
              <input
                type="text"
                value={config.name}
                onChange={(e) => setConfig(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                placeholder="my-mcp-server"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                版本号 *
              </label>
              <input
                type="text"
                value={config.version}
                onChange={(e) => setConfig(prev => ({ ...prev, version: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                placeholder="1.0.0"
                pattern="\d+\.\d+\.\d+"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                描述
              </label>
              <textarea
                value={config.description}
                onChange={(e) => setConfig(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                rows={3}
                placeholder="描述此 MCP Server 的功能..."
              />
            </div>
          </>
        )}

        {activeTab === 'transport' && (
          <>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                传输协议 *
              </label>
              <select
                value={config.transport}
                onChange={(e) => setConfig(prev => ({ ...prev, transport: e.target.value as 'stdio' | 'http' | 'websocket' }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="stdio">STDIO (本地进程通信)</option>
                <option value="http">HTTP (跨网络通信)</option>
                <option value="websocket">WebSocket (双向实时通信)</option>
              </select>
            </div>

            {(config.transport === 'http' || config.transport === 'websocket') && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  端口
                </label>
                <input
                  type="number"
                  value={config.port}
                  onChange={(e) => setConfig(prev => ({ ...prev, port: parseInt(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  placeholder="3000"
                />
              </div>
            )}
          </>
        )}

        {activeTab === 'auth' && (
          <>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                认证类型
              </label>
              <select
                value={config.authentication?.type || 'none'}
                onChange={(e) => setConfig(prev => ({
                  ...prev,
                  authentication: { ...prev.authentication, type: e.target.value as any }
                }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="none">无需认证</option>
                <option value="api_key">API Key</option>
                <option value="oauth2">OAuth2</option>
                <option value="jwt">JWT</option>
              </select>
            </div>

            {config.authentication?.type === 'api_key' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  API Key
                </label>
                <input
                  type="text"
                  value={config.authentication.apiKey || ''}
                  onChange={(e) => setConfig(prev => ({
                    ...prev,
                    authentication: { ...prev.authentication!, apiKey: e.target.value }
                  }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  placeholder="${API_KEY}"
                />
              </div>
            )}
          </>
        )}

        {activeTab === 'resources' && (
          <>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">资源列表</h3>
              <button
                type="button"
                onClick={addResource}
                className="px-3 py-1.5 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
              >
                + 添加资源
              </button>
            </div>

            {config.resources?.map((resource, index) => (
              <div key={index} className="border border-gray-200 rounded p-4 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="URI (如：mysql://tables/{table_name})"
                    value={resource.uri}
                    onChange={(e) => {
                      const newResources = [...(config.resources || [])];
                      newResources[index].uri = e.target.value;
                      setConfig(prev => ({ ...prev, resources: newResources }));
                    }}
                    className="px-3 py-2 border border-gray-300 rounded text-sm"
                  />
                  <input
                    type="text"
                    placeholder="名称"
                    value={resource.name}
                    onChange={(e) => {
                      const newResources = [...(config.resources || [])];
                      newResources[index].name = e.target.value;
                      setConfig(prev => ({ ...prev, resources: newResources }));
                    }}
                    className="px-3 py-2 border border-gray-300 rounded text-sm"
                  />
                </div>
                <textarea
                  placeholder="描述"
                  value={resource.description}
                  onChange={(e) => {
                    const newResources = [...(config.resources || [])];
                    newResources[index].description = e.target.value;
                    setConfig(prev => ({ ...prev, resources: newResources }));
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-sm"
                  rows={2}
                />
                <div className="flex gap-3">
                  <input
                    type="text"
                    placeholder="MIME 类型"
                    value={resource.mimeType}
                    onChange={(e) => {
                      const newResources = [...(config.resources || [])];
                      newResources[index].mimeType = e.target.value;
                      setConfig(prev => ({ ...prev, resources: newResources }));
                    }}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const newResources = config.resources?.filter((_, i) => i !== index);
                      setConfig(prev => ({ ...prev, resources: newResources }));
                    }}
                    className="px-3 py-2 text-red-600 hover:bg-red-50 rounded text-sm"
                  >
                    删除
                  </button>
                </div>
              </div>
            ))}
          </>
        )}

        {activeTab === 'tools' && (
          <>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">工具列表</h3>
              <button
                type="button"
                onClick={addTool}
                className="px-3 py-1.5 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
              >
                + 添加工具
              </button>
            </div>

            {config.tools?.map((tool, index) => (
              <div key={index} className="border border-gray-200 rounded p-4 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="工具名称"
                    value={tool.name}
                    onChange={(e) => {
                      const newTools = [...(config.tools || [])];
                      newTools[index].name = e.target.value;
                      setConfig(prev => ({ ...prev, tools: newTools }));
                    }}
                    className="px-3 py-2 border border-gray-300 rounded text-sm"
                  />
                  <select
                    value={tool.handler.type}
                    onChange={(e) => {
                      const newTools = [...(config.tools || [])];
                      newTools[index].handler.type = e.target.value as any;
                      setConfig(prev => ({ ...prev, tools: newTools }));
                    }}
                    className="px-3 py-2 border border-gray-300 rounded text-sm"
                  >
                    <option value="function">Function</option>
                    <option value="http">HTTP</option>
                    <option value="sql">SQL</option>
                  </select>
                </div>
                <textarea
                  placeholder="工具描述"
                  value={tool.description}
                  onChange={(e) => {
                    const newTools = [...(config.tools || [])];
                    newTools[index].description = e.target.value;
                    setConfig(prev => ({ ...prev, tools: newTools }));
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded text-sm"
                  rows={2}
                />
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      const newTools = config.tools?.filter((_, i) => i !== index);
                      setConfig(prev => ({ ...prev, tools: newTools }));
                    }}
                    className="px-3 py-2 text-red-600 hover:bg-red-50 rounded text-sm"
                  >
                    删除
                  </button>
                </div>
              </div>
            ))}
          </>
        )}
      </form>

      {/* 操作按钮 */}
      <div className="border-t border-gray-200 px-6 py-4 flex justify-between">
        <button
          type="button"
          onClick={() => onSave(config)}
          className="px-4 py-2 text-gray-700 bg-gray-100 rounded hover:bg-gray-200"
        >
          保存配置
        </button>
        <button
          type="button"
          onClick={() => onGenerate(config)}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          生成代码
        </button>
      </div>
    </div>
  );
}
