import { MCPServerConfig, CodeGenOptions } from './types';
import Handlebars from 'handlebars';

// TypeScript MCP Server 模板
const TYPESCRIPT_SERVER_TEMPLATE = `
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListResourcesRequestSchema,
  ListToolsRequestSchema,
  ReadResourceRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';

// Server configuration
const SERVER_NAME = '{{name}}';
const SERVER_VERSION = '{{version}}';

// Initialize server
const server = new Server(
  {
    name: SERVER_NAME,
    version: SERVER_VERSION,
  },
  {
    capabilities: {
      resources: {{#if resources}}true{{else}}false{{/if}},
      tools: {{#if tools}}true{{else}}false{{/if}},
      prompts: {{#if prompts}}true{{else}}false{{/if}},
    },
  }
);

{{#if authentication}}
// Authentication middleware
function authenticate(apiKey: string): boolean {
  const expectedKey = process.env.{{apiKeyEnv}};
  return apiKey === expectedKey;
}
{{/if}}

// Register resource handlers
{{#each resources}}
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  return {
    resources: [
      {
        uri: '{{uri}}',
        name: '{{name}}',
        description: '{{description}}',
        mimeType: '{{mimeType}}',
      },
    ],
  };
});

server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const { uri } = request.params;
  // TODO: Implement resource reading logic
  return {
    contents: [
      {
        uri,
        mimeType: '{{mimeType}}',
        text: 'Resource content here',
      },
    ],
  };
});
{{/each}}

// Register tool handlers
{{#each tools}}
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: '{{name}}',
        description: '{{description}}',
        inputSchema: {{{json inputSchema}}},
      },
    ],
  };
});

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  
  if (name === '{{name}}') {
    // TODO: Implement tool execution logic
    {{#if handler.endpoint}}
    // HTTP call: {{handler.method}} {{handler.endpoint}}
    {{/if}}
    {{#if handler.sqlQuery}}
    // SQL execution: {{handler.sqlQuery}}
    {{/if}}
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ result: 'success' }, null, 2),
        },
      ],
    };
  }
  
  throw new Error(\`Unknown tool: \${name}\`);
});
{{/each}}

// Start server
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error(\`{{name}} MCP Server running on stdio\`);
}

main().catch((error) => {
  console.error('Server error:', error);
  process.exit(1);
});
`;

// Python MCP Server 模板
const PYTHON_SERVER_TEMPLATE = `
{{"!"/usr/bin/env python3}}
"""
{{name}} - MCP Server

{{description}}
"""

import asyncio
import json
import os
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource,
    Tool,
    TextContent,
    CallToolResult,
    ReadResourceResult,
)

# Server configuration
SERVER_NAME = "{{name}}"
SERVER_VERSION = "{{version}}"

# Initialize server
server = Server(SERVER_NAME)


{{#each resources}}
@server.list_resources()
async def list_resources() -> list[Resource]:
    return [
        Resource(
            uri="{{uri}}",
            name="{{name}}",
            description="{{description}}",
            mimeType="{{mimeType}}",
        ),
    ]


@server.read_resource()
async def read_resource(uri: str) -> ReadResourceResult:
    # TODO: Implement resource reading logic
    return ReadResourceResult(
        contents=[
            {
                "uri": uri,
                "mimeType": "{{mimeType}}",
                "text": "Resource content here",
            }
        ]
    )

{{/each}}

{{#each tools}}
@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="{{name}}",
            description="{{description}}",
            inputSchema={{{json inputSchema}}},
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> CallToolResult:
    if name == "{{name}}":
        # TODO: Implement tool execution logic
        {{#if handler.endpoint}}
        # HTTP call: {{handler.method}} {{handler.endpoint}}
        {{/if}}
        {{#if handler.sqlQuery}}
        # SQL execution: {{handler.sqlQuery}}
        {{/if}}
        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=json.dumps({"result": "success"}, indent=2),
                )
            ]
        )
    
    raise ValueError(f"Unknown tool: {name}")

{{/each}}


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


if __name__ == "__main__":
    asyncio.run(main())
`;

export class CodeGenerator {
  private config: MCPServerConfig;
  private options: CodeGenOptions;

  constructor(config: MCPServerConfig, options: CodeGenOptions) {
    this.config = config;
    this.options = options;
  }

  generate(): Promise<Map<string, string>> {
    const files = new Map<string, string>();

    if (this.options.language === 'typescript') {
      files.set('server.ts', this.generateTypeScript());
      files.set('package.json', this.generatePackageJSON());
      
      if (this.options.includeTests) {
        files.set('server.test.ts', this.generateTypeScriptTests());
      }
      
      if (this.options.includeDockerfile) {
        files.set('Dockerfile', this.generateTypeScriptDockerfile());
      }
    } else if (this.options.language === 'python') {
      files.set('server.py', this.generatePython());
      files.set('requirements.txt', this.generateRequirements());
      
      if (this.options.includeTests) {
        files.set('test_server.py', this.generatePythonTests());
      }
      
      if (this.options.includeDockerfile) {
        files.set('Dockerfile', this.generatePythonDockerfile());
      }
    }

    return Promise.resolve(files);
  }

  private generateTypeScript(): string {
    const template = Handlebars.compile(TYPESCRIPT_SERVER_TEMPLATE);
    return template({
      ...this.config,
      apiKeyEnv: this.config.authentication?.apiKey?.replace(/\${|}/g, ''),
    });
  }

  private generatePackageJSON(): string {
    return JSON.stringify(
      {
        name: this.config.name,
        version: this.config.version,
        description: this.config.description,
        type: 'module',
        scripts: {
          start: 'node dist/server.js',
          dev: 'tsx watch src/server.ts',
          build: 'tsc',
          test: 'vitest',
        },
        dependencies: {
          '@modelcontextprotocol/sdk': '^0.5.0',
        },
        devDependencies: {
          '@types/node': '^20.10.0',
          typescript: '^5.3.0',
          tsx: '^4.6.0',
          vitest: '^1.0.0',
        },
      },
      null,
      2
    );
  }

  private generateTypeScriptTests(): string {
    return `
import { describe, it, expect } from 'vitest';
import { MCPServerConfig } from './types';

describe('${this.config.name}', () => {
  it('should initialize server', async () => {
    // TODO: Add server initialization tests
    expect(true).toBe(true);
  });

  ${this.config.tools?.map(tool => `
  it('should execute ${tool.name} tool', async () => {
    // TODO: Add tool execution tests
  });
  `).join('')}
});
`;
  }

  private generateTypeScriptDockerfile(): string {
    return `
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

EXPOSE ${this.config.port || 3000}

CMD ["npm", "start"]
`;
  }

  private generatePython(): string {
    const template = Handlebars.compile(PYTHON_SERVER_TEMPLATE, {
      preventIndent: true,
    });
    return template(this.config);
  }

  private generateRequirements(): string {
    return `
mcp>=0.1.0
${this.config.tools?.some(t => t.handler.type === 'http') ? 'requests>=2.31.0' : ''}
${this.config.tools?.some(t => t.handler.type === 'sql') ? 'sqlalchemy>=2.0.0' : ''}
pytest>=7.4.0
pytest-asyncio>=0.21.0
`.trim();
  }

  private generatePythonTests(): string {
    return `
import pytest
from server import main

@pytest.mark.asyncio
async def test_server_initialization():
    # TODO: Add server initialization tests
    assert True

${this.config.tools?.map(tool => `
@pytest.mark.asyncio
async def test_${tool.name}_tool():
    # TODO: Add tool execution tests
    assert True
`).join('\n')}
`;
  }

  private generatePythonDockerfile(): string {
    return `
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt ./
RUN pip install -r requirements.txt

COPY . .

EXPOSE ${this.config.port || 3000}

CMD ["python", "server.py"]
`;
  }
}

export async function generateMCPServerCode(
  config: MCPServerConfig,
  options: CodeGenOptions
): Promise<Map<string, string>> {
  const generator = new CodeGenerator(config, options);
  return generator.generate();
}
